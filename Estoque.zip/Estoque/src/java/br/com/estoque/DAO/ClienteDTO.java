
package br.com.estoque.DTO;


public class ClienteDTO {
    private int clienteId;
    private String cliente_nome;
    
    public int getClienteId(){
        return clienteId
    }
    
    public void setClienteId(int clienteId){
        this.clienteId = clienteId;
    }
    
    public String getClienteNome(){
        return clienteNome;
    }
    
    public void setClienteNome(String clienteNome){
        this.clienteNome = clienteNome;
    }
    
    public String getClienteEmail(){
        return clienteEmail;
    }
    
    public void setClienteEmail(String clienteEmail){
        this clienteEmail = clienteEmail;
    }
    
}
